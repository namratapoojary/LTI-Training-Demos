export class Occupation{
    CustomerOccupationId:string;
    OccupationType:string;
    SourceOfIncome:string;
    GrossAnnualIncome:string;
    DebitCard:string;
    
}
export class Transaction{
    TransactionID:string;
    TypeOfTransaction:string;
    CurrentBalance:string;
    TransactionDate:string; 
}
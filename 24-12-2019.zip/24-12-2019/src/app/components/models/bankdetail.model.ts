export class BankDetail{
    IFSCCode:string;
    BranchName:string;
    BranchAddress:string;
    MICRCode:string;
}
export class Beneficiary{
    BeneficiaryName:string;
    ReEnterAccountNumber:string;
    SaveBeneficiary:string;
    NickName:string;
}
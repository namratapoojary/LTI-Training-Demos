export class Address{
    CustomerAddressId:string;
    ResAddrLine1:string;
    ResAddrLine2:string;
    ResAddrLandmark:string;
    ResAddrDistrict:string;
    ResAddrCity:string;
    ResAddrState:string;
    ResAddrPincode:string;

    PermAddrLine1:string;
    PermAddrLine2:string;
    PermAddrLandmark:string;
    PermAddrDistrict:string;
    PermAddrCity:string;
    PermAddrState:string;
    PermAddrPincode:string;
}
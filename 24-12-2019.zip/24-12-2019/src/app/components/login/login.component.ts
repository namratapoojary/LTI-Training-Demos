import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private router: Router, private customersService: CustomerService) { }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      CustomerID: ['', [Validators.required,
      Validators.pattern('[0-9]{6}')]],
      LoginPassword: ['', Validators.required]

    });
  }

  verifyLogin() {
    this.submitted = true;

    //validation failed then
    if (this.loginForm.invalid)
      return;

    console.log(this.loginForm.value);

    this.customersService.verifyLogin(this.loginForm.value).subscribe(data => {
      // localStorage.customerID = this.loginForm.controls.CustomerID.value;

      alert(`Logged in successfully`);
      this.router.navigate(['/dashboard']);
    },
      err => {
        console.log(err.stack);
      })
    
  }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';
import { Customer } from '../models/customer.model';
import { Account } from '../models/account.model';
import { AccountService } from 'src/app/services/account.service';
import { Address } from '../models/address.model';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-open-account',
  templateUrl: './open-account.component.html',
  styleUrls: ['./open-account.component.css']
})
export class OpenAccountComponent implements OnInit {
  openAccountForm: FormGroup;
  addAddressForm: FormGroup;
  addOccupationForm: FormGroup;
  submitted: boolean = false;

  // Constructor Injection
  constructor(private formBuilder: FormBuilder,
    private router: Router, private customersService: CustomerService,
    private accountsService: AccountService) { }

  ngOnInit() {
    this.openAccountForm = this.formBuilder.group({
      Title: [''],
      FirstName: ['', [Validators.required,
      Validators.pattern("[A-Z][a-z]{2,25}")]],

      MiddleName: ['', Validators.pattern("[A-Za-z]{1,25}")],

      LastName: ['', [Validators.required,
      Validators.pattern("[A-Za-z]{0,25}")]],

      FatherName: ['', Validators.pattern("[A-Za-z]{0,25}")],

      MotherName: ['',
        Validators.pattern("[A-Za-z]{0,25}")],

      Gender: ['', Validators.required],

      DOB: ['', Validators.required],

      CustomerType: ['', Validators.required],

      Nationality: ['', Validators.required],

      MaritalStatus: ['', Validators.required],

      MobileNumber: ['', [Validators.required,
      Validators.pattern('[6-9][0-9]{9}')]],

      AlternateMobileNumber: ['', [Validators.required,
      Validators.pattern('[6-9][0-9]{9}')]],

      EmailID: ['', [Validators.required, Validators.email]],

      AadharNumber: ['', [Validators.required,
      Validators.pattern('[0-9]{12}')]],

      PanCardNumber: ['', [Validators.required,
      Validators.pattern('[A-Z]{5}[0-9]{4}[A-Z]')]],

      OccupationType: ['', [Validators.required,
      Validators.pattern("[A-Za-z]{3,26}")]],

      SourceOfIncome: ['', Validators.required],

      GrossAnnualIncome: ['', [Validators.required,
      Validators.pattern("[0-9]{14}")
    ]],

      DebitCard: ['', Validators.required]
    });

    
    this.addAddressForm = this.formBuilder.group({
      CustomerAddressId:[localStorage.CustomerID],
      ResAddrLine1: ['', Validators.required],

      ResAddrLine2: ['', Validators.required],

      ResAddrLandmark: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{4,26}")
      ]],

      ResAddrDistrict: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{4,26}")
      ]],

      ResAddrCity: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{3,26}")
      ]],

      ResAddrState: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{3,26}")
      ]],

      ResAddrPincode: ['', [Validators.required,
      Validators.pattern("[0-9]{6}")]],

      PermAddrLine1: ['', Validators.required],

      PermAddrLine2: ['', Validators.required],

      PermAddrLandmark: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{4,26}")
     ]],

      PermAddrDistrict: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{4,26}")
      ]],

      PermAddrCity: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{3,26}")
      ]], 

      PermAddrState: ['', [Validators.required,
      // Validators.pattern("[A-Za-z]{3,26}")
      ]],

      PermAddrPincode: ['', [Validators.required,
      Validators.pattern("[0-9]{6}")]],
    });


    this.addOccupationForm = this.formBuilder.group({
      CustomerOccupationId:[ localStorage.CustomerID],
      OccupationType: ['', [Validators.required,
      Validators.pattern("[A-Za-z]{3,26}")]],

      SourceOfIncome: ['', Validators.required],

      GrossAnnualIncome: ['', [Validators.required,
      // Validators.pattern("[0-9]") 
    ]],

      DebitCard: ['', Validators.required]
    });


  } // ngOnInit() function is over

  customer: any;
  address:any;
  occupation:any;

  addPersonalDetails() {
    // alert(1)
    this.submitted = true;
    // if (this.openAccountForm.invalid) {
    //   return;
    // }
    // alert(2)
    // let accountNumber = this.openAccountForm.controls.AccountNumber.value;
    // let customerID = this.openAccountForm.controls.CustomerId.value;
    console.log(this.openAccountForm.value);
    // alert(3)
    this.customersService.openAccount(this.openAccountForm.value).subscribe(data => {
      this.customer = data;
      // localStorage.accountNumber = this.openAccountForm.controls.AccountNumber.value;
      localStorage.CustomerID = this.customer.CustomerID;
      localStorage.AccountNumber = this.customer.AccountNumber;


      console.log(localStorage.CustomerID);
      console.log(localStorage.AccountNumber);

      this.initializeDefaultAccountDetails();


      // alert(`${this.openAccountForm.controls.FirstName.value}
      // account opened successfully`);
      // alert(4)
      // this.router.navigate(['']);
      // alert(5)
    }, err => {
      console.log(err.stack);
    })
  }

  account: any;
  initializeDefaultAccountDetails() {
    console.log('initializeDefaultAccountDetails()');
    let myDate = new Date();
    //let todaysDate = myDate.getDate() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getFullYear();
    // let todaysDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
    let today = new Date();
    let date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    let dateTime = date + ' ' + time;

    let defaultAccount = {
      AccountNumber: localStorage.AccountNumber,
      CustomerID: localStorage.CustomerID,
      OpeningBalance: 10000,
      AvailableBalance: 10000,
      ActualBalance: 10000,
      LoginPassword: localStorage.CustomerID,
      TransactionPassword: localStorage.CustomerID,
      AccountType: "Saving",
      ApplicationNumber: "A" + localStorage.CustomerID,
      ActOpeningDate: dateTime
    }
    console.log(defaultAccount);
    this.accountsService.initializeAccount(defaultAccount)
      .subscribe(data => {
        this.account = data;
        console.log(this.account);
      }, err => console.log(err.stack))
  }


  // ADDING VALUES TO ADDRESS TABLE


  addAddressDetails(){
     console.log('in add address')
   // this.address.CustomerID = localStorage.CustomerID
    this.submitted = true;
    //let CustomerID = localStorage.CustomerID;
    //this.address.CustomerID = this.customer.CustomerID

    console.log(this.addAddressForm.value);
    this.customersService.addAddress(this.addAddressForm.value)
        .subscribe(data => {
      this.address = data;
      }, err => {
        console.log(err.stack);
      })

  }


    // ADDING OCCUPATION      

    addOccupationDetails(){
    this.submitted = true;
    // this.occupation.CustomerID = localStorage.CustomerID


    //this.address.CustomerID = this.customer.CustomerID

    console.log(this.addOccupationForm.value);
    this.customersService.addOccupation(this.addOccupationForm.value)
        .subscribe(data => {
      this.occupation = data;
      Swal.fire(
        'Welcome To MPSN Bank',
        'Account Created Succesfully',
        'success'
      )
      }, err => {
        console.log(err.stack);
      })

  }


}



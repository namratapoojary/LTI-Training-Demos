import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { ListCustomerComponent } from './components/list-customer/list-customer.component';
import { OpenAccountComponent } from './components/open-account/open-account.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountDetailsComponent } from './components/dashboard/account-details/account-details.component';
import { AccountSummaryComponent } from './components/dashboard/account-summary/account-summary.component';
import { AccountStatementComponent } from './components/dashboard/account-statement/account-statement.component';
import { FundTransferComponent } from './components/dashboard/fund-transfer/fund-transfer.component';



const routes: Routes = [{ path:'login',component:LoginComponent},
{path:'home',component:HomeComponent},
{path:'openaccount',component:OpenAccountComponent},
{path:'listCustomer',component:ListCustomerComponent},
{path:'dashboard',component:DashboardComponent,
children: [
  { path: 'Details', component:AccountDetailsComponent },
  { path: 'summary', component:AccountSummaryComponent },
  { path: 'statement', component: AccountStatementComponent},
{path:'fundtransfer',component:FundTransferComponent}
]},
{path:'**',component:HomeComponent}];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

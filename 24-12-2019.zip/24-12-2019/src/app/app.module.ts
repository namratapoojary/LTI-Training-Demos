import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListCustomerComponent } from './components/list-customer/list-customer.component';
import { OpenAccountComponent } from './components/open-account/open-account.component';
import { HttpClientModule } from '@angular/common/http';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountDetailsComponent } from './components/dashboard/account-details/account-details.component';
import { AccountSummaryComponent } from './components/dashboard/account-summary/account-summary.component';
import { AccountStatementComponent } from './components/dashboard/account-statement/account-statement.component';
import { FundTransferComponent } from './components/dashboard/fund-transfer/fund-transfer.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    ListCustomerComponent,
    OpenAccountComponent,
    DashboardComponent,
    AccountDetailsComponent,
    AccountSummaryComponent,
    AccountStatementComponent,
    FundTransferComponent
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    BrowserModule,
    HttpClientModule,   
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

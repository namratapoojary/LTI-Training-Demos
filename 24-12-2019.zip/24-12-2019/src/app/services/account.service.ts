import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Account } from '../components/models/account.model';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http: HttpClient) { }

  private baseURL: string = "http://localhost:52442/api/account";

  
  
  initializeAccount(account: Account ){
    return this.http.post(this.baseURL, account);
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../components/models/customer.model';
import { Address } from '../components/models/address.model';
import { Account } from '../components/models/account.model';
import { Occupation } from '../components/models/occupation.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private baseURL: string = "http://localhost:52442/api/customers";
   private loginBaseURL: string = "http://localhost:52442/api/account";

  constructor(private http: HttpClient) { }
  getAllUsers() {
    return this.http.get<Customer[]>(this.baseURL);
  }

  openAccount(customer: Customer ){
    return this.http.post(this.baseURL+"/open", customer);
  }
  addAddress(address:Address){
    return this.http.post(this.baseURL+"/address",address);
  }
  addOccupation(occupation:Occupation){
    return this.http.post(this.baseURL+"/occupation",occupation);
  }

  verifyLogin(account: Account) {
    return this.http.post(this.loginBaseURL+"/login", account);
  }



}

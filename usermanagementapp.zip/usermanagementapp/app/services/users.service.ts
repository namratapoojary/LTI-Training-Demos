import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  // private baseURL : string = "/assets/data/ltidb.json";

  // private baseURL: string = "http://localhost:3000/users"

  private baseURL: string = "http://localhost:50918/api/Persons"
  constructor(private http: HttpClient) { }

  // LIST DISPLAY
  getAllUsers() {
    return this.http.get<User[]>(this.baseURL);
  }

  // GET USER BY ID
  getUserById(id: number) {
    return this.http.get<User>(this.baseURL + "/" + id);

  }


  //ADD USER
  addUser(user: User) {
    return this.http.post(this.baseURL, user);
  }


  //UPDATE USER
  updateUser(user: User) {
    return this.http.put(this.baseURL + "/" + user.ID, user);
    // return this.http.put(`${this.baseURL}/${user.id}`,user);
  }


  // DELETE USER BY ID
  deleteUser(id: number) {
    return this.http.delete(this.baseURL + "/" + id);
      // return this.http.delete(`${this.baseURL}/${user.id},user`)
  }
 
  searchByEmail(Email:string){
    return this.http.get<User[]>(this.baseURL + "/search/" + Email);
  }
}
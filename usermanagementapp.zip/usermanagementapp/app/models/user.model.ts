export class User{
    ID:number;
    FirstName:string;
    LastName:string;
    Age:number;
    MobileNumber:string;
    Email:string;
    Password:string;


    // id:number;
    // firstName:string;
    // lastName:string;
    // age:number;
    // mobileNumber:string;
    // email:string;
    // password:string;
}

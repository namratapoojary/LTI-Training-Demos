import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'email'
})
export class EmailPipe implements PipeTransform {

  transform(usersList :any ,searchEmail:any): any {
    let searchedList:any;
    if(searchEmail){
      searchedList = usersList.filter(user=>user.Email.toLowerCase().startsWith(searchEmail.toLowerCase()))
    }
    else{
      searchedList = usersList;
    }

    return searchedList;
  }

}

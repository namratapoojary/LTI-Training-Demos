import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/app/components/home/home.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { AddUserComponent } from 'src/app/components/add-user/add-user.component';
import { ListUserComponent } from 'src/app/components/list-user/list-user.component';
import { EditUserComponent } from 'src/app/components/edit-user/edit-user.component';
import { SearchEmailComponent } from './components/search-email/search-email.component';


const routes: Routes = [
  
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'list-user',component:ListUserComponent},
  {path:'add-user',component:AddUserComponent},
  {path:'search',component:SearchEmailComponent},

  {path:'edit-user/:id/:name',component:EditUserComponent},
  // {path:'edit-user',component:EditUserComponent},
  {path:'**',component:HomeComponent},
  // {path:'',component:HomeComponent},
  {path:'',redirectTo:'/home',pathMatch: 'full'}, 
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

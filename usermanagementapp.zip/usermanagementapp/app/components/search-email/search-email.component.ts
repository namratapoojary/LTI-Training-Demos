import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-search-email',
  templateUrl: './search-email.component.html',
  styleUrls: ['./search-email.component.css']
})
export class SearchEmailComponent implements OnInit {
  searchEmail: any;
  users: User[];
  constructor(private usersService: UsersService) { }

  ngOnInit() {
  }
  searchByEmail() {
    this.usersService.searchByEmail(this.searchEmail).subscribe((data) => {
      console.log(data);
      this.users = data;
    })
   }
}
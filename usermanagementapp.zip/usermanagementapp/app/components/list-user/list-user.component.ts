import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/services/users.service';
import { User } from 'src/app/models/user.model';
// import { CalcService } from 'src/app/services/calc.service';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {

  constructor(private router: Router, private usersService: UsersService) { }
  //  private calcService:CalcService) { }
  users: User[];
  searchBy: any;
  searchEmail:any;
  ngOnInit() {
    if (localStorage.email) {
      this.usersService.getAllUsers().subscribe(data => {
        //on success or on resolve 
        this.users = data;
        console.log(this.users);
      },
        err => {
          console.log(err.stack);
        })
    }
    else {
      this.router.navigate(['/login']);
    }
  }

  logOutUser() {
    if (localStorage.email) {
      localStorage.removeItem("email");
      this.router.navigate(['/login']);
    }
  }

  deleteUser(user: User) {
    let confirmYN = confirm('Do you want to delete current user or selected user?');

    if (confirmYN) {
      this.usersService.deleteUser(user.ID).subscribe(data => {
        this.users = this.users.filter(u => u !== user);
        console.log(this.users);
      });
      alert(user.FirstName + "'s record is deleted!");
    }
  }

  editUser(user: User) {
    //using local storage
    // localStorage.removeItem("editId");
    // localStorage.setItem("editId", user.ID.toString());
    // this.router.navigate(['edit-user']);

    //using route parameter
    this.router.navigate(['edit-user',user.ID]);
    // this.router.navigate(['edit-user'], { queryParams: { 'id':user.ID, 'name': user.FirstName } });
    console.log();
  }






  // showAddition(){
  //   let res = this.calcService.addition(30,50);
  //   alert('Addition is '+res);
  // }

}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;

  // TO CHECK WHETHER LOGIN BUTTON IS CLICKED
  submitted: boolean = false;
  invalidLogin: boolean=false;

  // CONSTRUCTOR INJECTION  
  constructor(private formBuilder: FormBuilder, private router: Router) {

  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  verifyLogin() {
    this.submitted = true;

    // IF VALIDATION IS FAILED FOR ANY ONE OF THE CONTROL THEN IT WILL NOT EXECUTE CODE WHICH IS WRITTEN AFTER RETURN STATEMENT
    if (this.loginForm.invalid)
      return;
    let email = this.loginForm.controls.email.value;
    let password = this.loginForm.controls.password.value;

    if (email === "admin@gmail.com" && password === "123456") {
      localStorage.email = email;
      this.router.navigate(['list-user']);
    }
    else {
      this.invalidLogin =true;

    }
  }
}

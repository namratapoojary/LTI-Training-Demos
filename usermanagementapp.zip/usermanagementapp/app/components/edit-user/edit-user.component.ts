import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Models/user.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UsersService } from 'src/app/Services/users.service';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  user: User;
  editForm: FormGroup;
  submitted: boolean = false;
  userId:number;
  userName:string;
  constructor(private formBuilder: FormBuilder, private router: Router,
    private usersService: UsersService, private route: ActivatedRoute) {
      //ActivatedRoute class will read values of parameters frmo active 
    //from route parameter
    this.route.params.subscribe(params=>this.userId = params["id"])
    this.route.params.subscribe(params=>this.userId = params["firstName"])

  }

  ngOnInit() {
    if (localStorage.email) {
      // let userId = localStorage.getItem("editId");
      

      // if (!userId) {
      //   alert("Invalid action.")
      //   this.router.navigate(['list-user']);
      //   return;
      // }
      this.editForm = this.formBuilder.group({
        ID: [this.userId],
        FirstName: [{ value: '', disabled: true }, [Validators.required, Validators.pattern("[A-Z][a-z]{3,25}")]],
        LastName: [{ value: '', disabled: true }, Validators.required],
        Age: ['', [Validators.required, Validators.min(20), Validators.max(30)]],
        MobileNumber: ['', [Validators.required, Validators.pattern('[6-9][0-9]{9}')]],
        Email: ['', [Validators.required, Validators.email]],
        Password: ['', Validators.required]

      });

      this.usersService.getUserById(+this.userId)
        .subscribe(data => {
          this.editForm.setValue(data);
        });
    }
    else
      this.router.navigate(['/login']);
  }
  editUser() {
    this.submitted = true;
    if (this.editForm.invalid) {
      return;
    }
    this.usersService.updateUser(this.editForm.getRawValue())
      .subscribe(
        Data => {
          Swal.fire(
            'Updated!',
            'you have successfully updated details!',
            'success'
          )
          this.router.navigate(['list-user']);
        },
        error => {
          alert(error);
        });
  }


}
import { Component } from '@angular/core';
// import { setInterval } from 'timers';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'A-Z Solutions - user management app';
  todaysDate=new Date();
  /**
   *
   */
  constructor() {
    setInterval(()=>{
      this.todaysDate = new Date();
    },1000);
  }
}

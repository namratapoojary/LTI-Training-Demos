export class Account{
    AccountNumber:string;
    OpeningBalance:number;
    AvailableBalance:number;
    ActualBalance:number;
    LoginPassword:string;
    TransactionPassword:string;
    AccountType:string;
    ApplicationNumber:string;
    ActOpeningDate:string;
}

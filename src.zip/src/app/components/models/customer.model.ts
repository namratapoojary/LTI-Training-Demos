export class Customer{
    CustomerID:string;
    Title:string;
    FirstName:string;
    MiddleName:string;
    LastName:string;
    FatherName:string;
    MotherName:string;
    DOB:string;
    CustomerType: string;
    Gender: string;
    Nationality: string;
    MaritalStatus: string;
    MobileNumber:string;
    AlternateMobileNumber:string;
    AadharNumber:string;
    PanCardNumber:string;
    EmailID:string;
    OTP:number;
}
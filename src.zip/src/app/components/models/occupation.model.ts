export class Occupation{
    OccupationType:string;
    SourceOfIncome:string;
    GrossAnnualIncome:string;
    DebitCard:boolean;
}
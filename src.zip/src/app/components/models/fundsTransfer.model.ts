export class FundsTransfer{
    ReferenceID:string;
    FromAccountNumber:string;
    ToAccountNumber:string;
    ModeOfFundsTransfer:string;
    Amount:string;
    TransactionDate:string;
    MaturityInstructions:string;
    Remark:string;
}
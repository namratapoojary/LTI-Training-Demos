import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-open-account',
  templateUrl: './open-account.component.html',
  styleUrls: ['./open-account.component.css']
})
export class OpenAccountComponent implements OnInit {
  openAccountForm: FormGroup;
  submitted: boolean = false;

  // Constructor Injection
  constructor(private formBuilder: FormBuilder,
    private router: Router, private customersService:CustomerService) { }

  ngOnInit() {
    this.openAccountForm = this.formBuilder.group({
      Title:[''],
      FirstName: ['', [Validators.required,
      Validators.pattern("[A-Z][a-z]{2,25}")]],

      MiddleName: ['', 
        Validators.pattern("[A-Za-z]{1,25}")],

      LastName: ['', Validators.required,
      Validators.pattern("[A-Za-z]{0,25}")],

      FatherName: ['', [Validators.required,
        Validators.pattern("[A-Za-z]{0,25}")]],
        
      MotherName: ['', 
      Validators.pattern("[A-Za-z]{0,25}")],

     

      DateOfBirth: ['', Validators.required],

      gender: ['', Validators.required],

      ResAddressLine1: ['', Validators.required],

      ResAddressLine2: ['', Validators.required],

      ResLandmark: ['', Validators.required],

      city: ['', Validators.required],

      state: ['', Validators.required],

      PincodeRA: ['', Validators.required],

      Email: ['', [Validators.required, Validators.email]],

      MobileNumber: ['', [Validators.required,
        Validators.pattern('[6-9][0-9]{9}')]],

        AadharNumber: ['', [Validators.required]],

        PancardNumber: ['', [Validators.required]],

        OccupationType: ['', Validators.required],

        SourceOfIncome: ['', Validators.required],

        GrossAnnualIncome: ['', Validators.required],



      password: ['', Validators.required]
    });

  //   if (localStorage.email == null) {
  //     this.router.navigate(['/login']);
  //   }
  } // ngOnInit() function is over

  addCustomer() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }

    console.log(this.addForm.value);

    this.customersService.openAccount(this.addForm.value)
      .subscribe(data => {
        alert(`${this.addForm.controls.firstName.value}
       record is added successfully ..!`);
        this.router.navigate(['list-user']);
      }, err => {
        console.log(err.stack);
      })
  }
}



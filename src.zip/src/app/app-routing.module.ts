import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { ListCustomerComponent } from './components/list-customer/list-customer.component';
import { OpenAccountComponent } from './components/open-account/open-account.component';



const routes: Routes = [{
  path:'login',component:LoginComponent
},
{
  path:'home',component:HomeComponent
},
{
  path:'openaccount',component:OpenAccountComponent
},
{
  path:'listCustomer',component:ListCustomerComponent
},

{
  path:'**',component:HomeComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

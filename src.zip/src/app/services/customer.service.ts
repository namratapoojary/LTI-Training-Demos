import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../components/models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private baseURL:string = "http://localhost:52442/api/customers";

  constructor(private http:HttpClient) { }
  getAllUsers()
  {
    return this.http.get<Customer[]>(this.baseURL);
  }

  openAccount(customer:Customer){
    return this.http.post(this.baseURL,customer);
      }

}
